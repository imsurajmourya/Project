package project.bfour.debtormaintenance.customexceptions;

public class UnauthException extends RuntimeException {
    public UnauthException() {
        super();
    }
}
